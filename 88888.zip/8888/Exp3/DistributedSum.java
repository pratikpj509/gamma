import mpi.*;

public class DistributedSum {
    public static void main(String[] args) throws MPIException {
        MPI.Init(args);

        int rank = MPI.COMM_WORLD.Rank(); 
        int size = MPI.COMM_WORLD.Size(); 

        int[] array = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10};

        int localSum = 0; 
        int[] recvBuffer = new int[1]; 

        
        int startIndex = rank * (array.length / size);
        int endIndex = (rank + 1) * (array.length / size);
        for (int i = startIndex; i < endIndex; i++) {
            localSum += array[i];
        }

        
        System.out.println("Process " + rank + " intermediate sum: " + localSum);

        
        MPI.COMM_WORLD.Reduce(new int[]{localSum}, 0, recvBuffer, 0, 1, MPI.INT, MPI.SUM, 0);

        
        if (rank == 0) {
            System.out.println("Final sum: " + recvBuffer[0]);
        }

        MPI.Finalize();
    }
}
