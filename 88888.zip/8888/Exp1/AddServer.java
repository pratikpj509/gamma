import java.rmi.Naming;

public class AddServer {
    public static void main(String args[]) {
        try {
            AddServerImpl addServerImpl = new AddServerImpl();
            Naming.rebind("//localhost/AddServer", addServerImpl);
            System.out.println("Server is running...");
        } catch (Exception e) {
            System.out.println("Exception in main: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
//1st
//javac AddServer.java
//rmic AddserverImpl
//rmiregistry &
//2nd java AddServer
//3rd 
//javac AddClient.java
//java AddClient localhost 8 9
